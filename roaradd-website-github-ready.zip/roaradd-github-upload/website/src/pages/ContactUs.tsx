import { motion } from "framer-motion";
import { Link } from "wouter";
import { Mail, Phone, MapPin, Clock, MessageSquare, ChevronLeft, ArrowRight, Zap, Users, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ContactUs() {
  return (
    <div className="relative min-h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      <div className="fixed top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] bg-primary/10 blur-[150px] rounded-full pointer-events-none" />

      <main className="pt-20">
        <section className="py-24">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/">
                <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-white transition-colors mb-8 group">
                  <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
                </button>
              </Link>

              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-sm font-medium mb-6">
                <MessageSquare className="w-3.5 h-3.5" />
                Let's Talk
              </div>

              <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
                Contact <span className="text-gradient">Us</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-12 max-w-2xl leading-relaxed">
                Whether you have a project in mind, need strategic advice, or want to learn more about the RoarAdd ecosystem — we're here to help.
              </p>

              <div className="grid lg:grid-cols-2 gap-12 items-start">
                {/* Contact Cards */}
                <div className="grid sm:grid-cols-2 gap-6">
                  <a href="mailto:contactus@roaradd.com" className="glass-panel p-8 border border-white/10 hover:border-primary/40 transition-all group">
                    <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <Mail className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Email Us</h3>
                    <p className="text-sm text-muted-foreground mb-4">Typical response within 24 hours.</p>
                    <p className="text-primary font-medium group-hover:underline">contactus@roaradd.com</p>
                  </a>

                  <a href="tel:+17345460143" className="glass-panel p-8 border border-white/10 hover:border-green-500/40 transition-all group">
                    <div className="w-12 h-12 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <Phone className="w-6 h-6 text-green-400" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Call Us</h3>
                    <p className="text-sm text-muted-foreground mb-4">Available Mon-Fri, 9am-6pm EST.</p>
                    <p className="text-green-400 font-medium group-hover:underline">+1 734-546-0143</p>
                  </a>

                  <div className="glass-panel p-8 border border-white/10 col-span-full">
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-6 text-sm text-muted-foreground">
                      <span className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-primary" />
                        Global — Remote First
                      </span>
                      <span className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-primary" />
                        24-Hour Response Guarantee
                      </span>
                      <span className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        Accepting New Projects
                      </span>
                    </div>
                  </div>
                </div>

                {/* Info Card */}
                <div className="glass-panel p-8 border border-blue-500/20">
                  <h3 className="text-2xl font-bold mb-6">How can we help?</h3>
                  <div className="space-y-6">
                    {[
                      { icon: Zap, title: "Start a Project", desc: "Consult with our experts to build your next-gen solution." },
                      { icon: Users, title: "Enterprise Consulting", desc: "Custom implementations of Trackit and Farm at scale." },
                      { icon: ShieldCheck, title: "Security & Compliance", desc: "Audit your IT infrastructure and ensure compliance." },
                    ].map((item) => (
                      <div key={item.title} className="flex gap-4">
                        <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0">
                          <item.icon className="w-5 h-5 text-blue-400" />
                        </div>
                        <div>
                          <h4 className="font-bold text-white mb-1">{item.title}</h4>
                          <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                    <div className="pt-6">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2">
                        Book a Discovery Call <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  );
}
