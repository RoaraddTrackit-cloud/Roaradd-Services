import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Globe, MessageSquare, Shield, Smartphone, Zap, Cpu, Lock, Network, Bot, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const features = [
  { 
    icon: Globe, 
    title: "Worldwide Reach", 
    desc: "Send messages to any number, anywhere in the world. Our global bridge network ensures delivery regardless of carrier or location.",
    color: "text-cyan-400" 
  },
  { 
    icon: Shield, 
    title: "Zero Cost, Zero Ads", 
    desc: "A truly free service. No subscription fees, no per-message costs, and no invasive advertising in your private conversations.",
    color: "text-green-400" 
  },
  { 
    icon: Lock, 
    title: "Privacy First", 
    desc: "End-to-end encryption for every message. We don't store your content, and we don't track your metadata.",
    color: "text-purple-400" 
  },
];

const capabilities = [
  { icon: MessageSquare, title: "P2P Messaging", risk: "LOW RISK", riskColor: "text-green-400 bg-green-500/10 border-green-500/20", desc: "Standard person-to-person text communication across international borders." },
  { icon: Bot, title: "AI-Assisted Replies", risk: "LOW RISK", riskColor: "text-green-400 bg-green-500/10 border-green-500/20", desc: "Optional AI summarizing and smart reply suggestions integrated into your workflow." },
  { icon: Shield, title: "Bulk / Broadcast", risk: "HIGH RISK — Human Required", riskColor: "text-orange-400 bg-orange-500/10 border-orange-500/20", desc: "Automated or high-volume messaging requires identity verification and human approval." },
];

const steps = [
  { icon: Smartphone, title: "App Launch", desc: "Open the Fruiture app or visit roaradd.com/Fruiture to access the messaging gateway.", num: "1" },
  { icon: Network, title: "Global Handshake", desc: "Our bridge network establishes a secure connection to the destination carrier's SMS gateway.", num: "2" },
  { icon: Zap, title: "Instant Delivery", desc: "Messages are routed through the most efficient global path for sub-second delivery.", num: "3" },
  { icon: CheckCircle2, title: "Confirmation", desc: "Real-time delivery receipts and read status updates across all platforms.", num: "4" },
];

export default function FutureOfFuture() {
  return (
    <div className="relative min-h-screen bg-background overflow-hidden">
      {/* Background Effects */}
      <div className="fixed inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      <div className="fixed top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] bg-cyan-500/10 blur-[150px] rounded-full pointer-events-none" />

      <main className="pt-20">
        {/* HERO */}
        <section className="py-24">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/30 to-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                  <MessageSquare className="w-8 h-8 text-cyan-400" />
                </div>
              </div>
              <Badge className="mb-6 bg-cyan-500/10 text-cyan-400 border-cyan-500/20 uppercase tracking-widest">Future of Future Initiative</Badge>
              <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
                Free Worldwide<br /><span className="text-gradient">Text Messages</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-4 max-w-3xl mx-auto leading-relaxed">
                Communication is a human right. We're making it free, borderless, and secure. Built on the RoarAdd bridge protocol, Fruiture connects everyone, everywhere.
              </p>
              <p className="text-muted-foreground mb-12 max-w-xl mx-auto">No SIM card required. No per-message fees. Just connection.</p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg" variant="gradient" asChild className="gap-2 group">
                  <a href="https://roaradd.com/Fruiture" target="_blank" rel="noopener noreferrer">
                    Launch Fruiture <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </a>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/services/it-consulting">Developer API Access</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* CORE FEATURES */}
        <section className="py-24 border-t border-white/5 bg-cyan-500/5">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-12">The Fruiture Experience</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((f, i) => (
                <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <div className="glass-panel p-8 h-full border border-white/10 text-center">
                    <div className={`w-14 h-14 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-6`}>
                      <f.icon className={`w-7 h-7 ${f.color}`} />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{f.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{f.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="py-24 border-t border-white/5">
          <div className="max-w-5xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">How it works</h2>
              <p className="text-muted-foreground text-lg">Our global bridge technology simplifies worldwide communication.</p>
            </div>
            <div className="relative">
              <div className="absolute left-7 top-8 bottom-8 w-px bg-gradient-to-b from-cyan-500/50 to-transparent hidden md:block" />
              <div className="space-y-6">
                {steps.map((s, i) => (
                  <motion.div key={s.num} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                    <div className="flex gap-6 items-start">
                      <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center flex-shrink-0 z-10">
                        <s.icon className="w-6 h-6 text-cyan-400" />
                      </div>
                      <div className="glass-panel rounded-2xl p-5 flex-1 border border-white/10">
                        <div className="flex items-center gap-3 mb-1">
                          <span className="text-xs font-bold text-cyan-400/60">STEP {s.num}</span>
                          <h3 className="font-bold text-white">{s.title}</h3>
                        </div>
                        <p className="text-sm text-muted-foreground">{s.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CAPABILITIES & RISK */}
        <section className="py-24 border-t border-white/5 bg-secondary/20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Messaging Capabilities</h2>
              <p className="text-muted-foreground text-lg">Fruiture supports multiple interaction modes with built-in safety controls.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {capabilities.map((c, i) => (
                <motion.div key={c.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <Card className="glass-panel h-full">
                    <CardHeader>
                      <c.icon className={`w-8 h-8 text-cyan-400 mb-2`} />
                      <Badge className={`w-fit text-xs mb-2 ${c.riskColor} border`}>{c.risk}</Badge>
                      <CardTitle className="text-lg">{c.title}</CardTitle>
                      <CardDescription>{c.desc}</CardDescription>
                    </CardHeader>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* TECH STACK */}
        <section className="py-24 border-t border-white/5">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Powered by RoarAdd Infrastructure</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[
                { icon: Network, name: "Bridge Protocol", color: "text-cyan-400" },
                { icon: Shield, name: "E2E Encryption", color: "text-green-400" },
                { icon: Cpu, name: "Vertex AI", color: "text-yellow-400" },
                { icon: Globe, name: "Edge Routing", color: "text-blue-400" },
                { icon: Bot, name: "A2A Gateway", color: "text-purple-400" },
              ].map((tech) => (
                <div key={tech.name} className="glass-panel rounded-2xl p-4 border border-white/10 text-center">
                  <tech.icon className={`w-7 h-7 ${tech.color} mx-auto mb-2`} />
                  <p className="text-xs font-medium text-muted-foreground">{tech.name}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FINAL CTA */}
        <section className="py-24 border-t border-white/5">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">Experience the Future</h2>
              <p className="text-muted-foreground text-lg mb-10">Start sending free worldwide text messages today with Fruiture.</p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg" variant="gradient" asChild className="gap-2">
                  <a href="https://roaradd.com/Fruiture" target="_blank" rel="noopener noreferrer">Launch Fruiture <ArrowRight className="w-4 h-4" /></a>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/services/it-consulting">Request Business Access</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  );
}
