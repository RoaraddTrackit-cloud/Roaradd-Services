import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Bot, Building2, Cpu, Globe, Heart, LayoutDashboard, Leaf, Network, ShieldCheck, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const team = [
  {
    name: "Marcus T.",
    role: "Principal IT Consultant",
    bio: "15+ years delivering enterprise infrastructure across healthcare, fintech, and logistics. Led cloud migrations for organizations with 500+ seat deployments.",
    expertise: ["Cloud Architecture", "Enterprise IT", "GCP"],
    initials: "MT",
    color: "from-blue-500/30 to-blue-500/10 border-blue-500/30",
    textColor: "text-blue-400",
  },
  {
    name: "Priya S.",
    role: "AI & Data Systems Lead",
    bio: "Former senior data engineer at a Fortune 500. Specializes in designing AI-powered data pipelines and integrating machine learning into existing workflows.",
    expertise: ["AI Integration", "Data Architecture", "Vertex AI"],
    initials: "PS",
    color: "from-purple-500/30 to-purple-500/10 border-purple-500/30",
    textColor: "text-purple-400",
  },
  {
    name: "Jordan K.",
    role: "Security & Compliance Expert",
    bio: "Certified in CISSP and ISO 27001. Has conducted 80+ IT security audits across regulated industries — finance, healthcare, and government.",
    expertise: ["IT Security", "Compliance", "SOC 2"],
    initials: "JK",
    color: "from-red-500/30 to-red-500/10 border-red-500/30",
    textColor: "text-red-400",
  },
  {
    name: "Alex R.",
    role: "RoarAdd Product Integrations Lead",
    bio: "Deep expertise in deploying Trackit and Farm across enterprise clients. Your dedicated point of contact for all RoarAdd ecosystem implementations.",
    expertise: ["Trackit", "Farm", "System Integration"],
    initials: "AR",
    color: "from-green-500/30 to-green-500/10 border-green-500/30",
    textColor: "text-green-400",
  },
];

const values = [
  { icon: Zap, color: "text-yellow-400", title: "Speed with Substance", desc: "We ship fast, but never at the expense of quality. Every product is built to last." },
  { icon: ShieldCheck, color: "text-green-400", title: "Safety First", desc: "Human-in-the-loop controls are non-negotiable in everything we build involving AI." },
  { icon: Heart, color: "text-pink-400", title: "Built with Care", desc: "We build tools we'd want to use ourselves. That empathy shows in every detail." },
  { icon: Network, color: "text-primary", title: "Ecosystem Thinking", desc: "Every product is designed to connect with the others. No silos. No dead ends." },
  { icon: Globe, color: "text-blue-400", title: "Industry Depth", desc: "We don't just know technology — we understand the industries we serve." },
  { icon: Cpu, color: "text-purple-400", title: "AI-Native", desc: "AI isn't an add-on for us. It's baked into the foundation of everything." },
];

export default function About() {
  return (
    <div className="relative min-h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      <div className="fixed top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-primary/10 blur-[140px] rounded-full pointer-events-none" />

      <main className="pt-16">
        {/* HERO */}
        <section className="py-20 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7 }}>
                <Badge variant="outline" className="mb-6 py-1 px-3 bg-primary/10 border-primary/20 text-primary text-xs uppercase tracking-widest">About RoarAdd</Badge>
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 leading-tight">
                  We build the tools <span className="text-gradient">we wish existed.</span>
                </h1>
                <p className="text-xl text-muted-foreground mb-6 leading-relaxed">
                  RoarAdd is a technology company based in Loganville, GA, building interconnected software and services for the next generation of business — from smart SaaS tools to AI-to-AI infrastructure.
                </p>
                <p className="text-muted-foreground mb-10 leading-relaxed">
                  We started with a simple belief: the best tools are built by people who deeply understand the problems they're solving. That's why our team combines enterprise IT expertise, agricultural knowledge, and cutting-edge AI engineering — all under one roof.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button variant="gradient" asChild className="gap-2 group">
                    <Link href="/contact">Work with us <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/services/it-consulting">Our Services</Link>
                  </Button>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.2 }}>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: "2023", label: "Founded" },
                    { value: "12+", label: "Industries Served" },
                    { value: "500+", label: "Enterprise Seats" },
                    { value: "4", label: "Products & Services" },
                  ].map((stat) => (
                    <div key={stat.label} className="glass-panel rounded-2xl p-6 border border-white/10 text-center">
                      <p className="text-3xl font-extrabold text-white mb-2">{stat.value}</p>
                      <p className="text-sm text-muted-foreground leading-snug">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* STORY */}
        <section className="py-20 sm:py-24 border-t border-white/5 bg-secondary/20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-8">Our Story</h2>
              <div className="space-y-5 text-muted-foreground text-lg leading-relaxed text-left">
                <p>RoarAdd LLC was founded with a straightforward observation: most business software is built by people who have never worked in the industries they're serving. The result is generic tools that sort of work for everyone and perfectly serve no one.</p>
                <p>We set out to fix that. By combining deep domain expertise in agriculture, enterprise IT, and AI systems, we built an ecosystem where every product and service is genuinely designed for the people using it — not retrofitted from a generic template.</p>
                <p>Today, RoarAdd operates across four core areas: Trackit (smart analytics), Farm (agricultural management), IT Consulting, and AIP (our AI-to-AI gateway) — all interconnected, all designed to grow with our clients.</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* VALUES */}
        <section className="py-20 sm:py-24 border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">What we believe</h2>
              <p className="text-muted-foreground text-lg">The principles that guide everything we build.</p>
            </motion.div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
              {values.map((v, i) => (
                <motion.div key={v.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}>
                  <Card className="glass-panel h-full">
                    <CardHeader>
                      <v.icon className={`w-8 h-8 ${v.color} mb-3`} />
                      <CardTitle className="text-lg">{v.title}</CardTitle>
                      <CardDescription>{v.desc}</CardDescription>
                    </CardHeader>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* TEAM */}
        <section className="py-20 sm:py-24 border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">The people behind the work</h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Real practitioners — not generalists. Hands-on experience from industries like fintech, healthcare, agriculture, and enterprise tech.</p>
            </motion.div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
              {team.map((member, i) => (
                <motion.div key={member.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <Card className="glass-panel h-full border border-white/10 hover:border-white/20 transition-all">
                    <CardHeader className="pb-4">
                      <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${member.color} border flex items-center justify-center mb-4`}>
                        <span className={`text-xl font-black ${member.textColor}`}>{member.initials}</span>
                      </div>
                      <CardTitle className="text-lg leading-snug">{member.name}</CardTitle>
                      <p className={`text-sm font-medium ${member.textColor}`}>{member.role}</p>
                      <CardDescription className="mt-2 leading-relaxed">{member.bio}</CardDescription>
                    </CardHeader>
                    <div className="px-6 pb-6 flex flex-wrap gap-1.5">
                      {member.expertise.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ECOSYSTEM */}
        <section className="py-20 sm:py-24 border-t border-white/5 bg-secondary/20">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Explore the ecosystem</h2>
            </motion.div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: LayoutDashboard, color: "text-primary", href: "/trackit", name: "Trackit", desc: "Analytics & tracking" },
                { icon: Leaf, color: "text-green-400", href: "/farm", name: "Farm", desc: "Farm management" },
                { icon: Building2, color: "text-blue-400", href: "/services/it-consulting", name: "IT Consulting", desc: "Cloud & enterprise" },
                { icon: Bot, color: "text-purple-400", href: "/services/aip", name: "AIP", desc: "AI-to-AI gateway" },
              ].map((item) => (
                <Link key={item.name} href={item.href}>
                  <div className="glass-panel rounded-2xl p-5 border border-white/10 hover:border-white/20 transition-all text-center cursor-pointer group">
                    <item.icon className={`w-7 h-7 ${item.color} mx-auto mb-3 group-hover:scale-110 transition-transform`} />
                    <p className="font-semibold text-white text-sm">{item.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 sm:py-24 border-t border-white/5">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Want to work with us?</h2>
              <p className="text-muted-foreground mb-10">Whether you're interested in our products, services, or a partnership — we'd love to hear from you.</p>
              <Button size="lg" variant="gradient" asChild className="gap-2">
                <Link href="/contact">Get in Touch <ArrowRight className="w-4 h-4" /></Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  );
}
