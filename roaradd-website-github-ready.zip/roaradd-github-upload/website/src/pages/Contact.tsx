import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Bot, Building2, LayoutDashboard, Leaf, Mail, MapPin, MessageSquare, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", company: "", message: "", interest: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, wire this to your backend/email service
    setSubmitted(true);
  };

  return (
    <div className="relative min-h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      <div className="fixed top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-primary/10 blur-[140px] rounded-full pointer-events-none" />

      <main className="pt-16">
        {/* HERO */}
        <section className="py-20 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
              <Badge variant="outline" className="mb-6 py-1.5 px-4 bg-primary/10 border-primary/20 text-primary uppercase tracking-widest text-xs">Get in Touch</Badge>
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 leading-tight">
                Let's talk about <span className="text-gradient">your project.</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Whether you're exploring our products, need IT consulting, or want to integrate AIP — we're here to help. Book a free discovery call or send us a message.
              </p>
            </motion.div>
          </div>
        </section>

        {/* CONTACT GRID */}
        <section className="pb-20 sm:pb-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
              {/* FORM */}
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
                <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-white/10">
                  {submitted ? (
                    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
                      <div className="w-16 h-16 rounded-full bg-green-500/20 border border-green-500/30 flex items-center justify-center mx-auto mb-4">
                        <MessageSquare className="w-8 h-8 text-green-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-3">Message sent!</h3>
                      <p className="text-muted-foreground mb-6">We'll get back to you within 1–2 business days.</p>
                      <Button variant="outline" onClick={() => setSubmitted(false)}>Send another message</Button>
                    </motion.div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-5">
                      <div>
                        <h2 className="text-2xl font-bold text-white mb-1">Send us a message</h2>
                        <p className="text-sm text-muted-foreground">We respond within 1–2 business days.</p>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-sm text-white">Full Name</Label>
                          <Input
                            id="name"
                            placeholder="Your name"
                            required
                            value={form.name}
                            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                            className="bg-white/5 border-white/10 text-white placeholder:text-muted-foreground focus:border-primary/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-sm text-white">Email Address</Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="you@company.com"
                            required
                            value={form.email}
                            onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                            className="bg-white/5 border-white/10 text-white placeholder:text-muted-foreground focus:border-primary/50"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="company" className="text-sm text-white">Company (optional)</Label>
                        <Input
                          id="company"
                          placeholder="Your company name"
                          value={form.company}
                          onChange={e => setForm(f => ({ ...f, company: e.target.value }))}
                          className="bg-white/5 border-white/10 text-white placeholder:text-muted-foreground focus:border-primary/50"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="text-sm text-white">I'm interested in</Label>
                        <div className="flex flex-wrap gap-2">
                          {["Trackit", "Farm", "IT Consulting", "AIP", "General Inquiry"].map(option => (
                            <button
                              type="button"
                              key={option}
                              onClick={() => setForm(f => ({ ...f, interest: option }))}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                                form.interest === option
                                  ? "bg-primary/20 border-primary/40 text-primary"
                                  : "bg-white/5 border-white/10 text-muted-foreground hover:border-white/20"
                              }`}
                            >
                              {option}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message" className="text-sm text-white">Message</Label>
                        <textarea
                          id="message"
                          required
                          rows={5}
                          placeholder="Tell us about your project, goals, or questions..."
                          value={form.message}
                          onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                          className="w-full rounded-lg bg-white/5 border border-white/10 text-white placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none focus:ring-0 px-3 py-2 text-sm resize-none"
                        />
                      </div>

                      <Button type="submit" variant="gradient" size="lg" className="w-full gap-2">
                        Send Message <ArrowRight className="w-4 h-4" />
                      </Button>
                    </form>
                  )}
                </div>
              </motion.div>

              {/* SIDEBAR INFO */}
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="space-y-6">
                {/* Direct contact */}
                <div className="glass-panel rounded-2xl p-6 border border-white/10">
                  <h3 className="font-bold text-white mb-4">Direct Contact</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0">
                        <Mail className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Email</p>
                        <a href="mailto:kalyan.modium@roaradd.com" className="text-sm text-white hover:text-primary transition-colors">kalyan.modium@roaradd.com</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-4 h-4 text-green-400" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Location</p>
                        <p className="text-sm text-white">Loganville, GA</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Book a call */}
                <div className="glass-panel rounded-2xl p-6 border border-primary/20 bg-primary/5">
                  <h3 className="font-bold text-white mb-2">Book a Free Discovery Call</h3>
                  <p className="text-sm text-muted-foreground mb-4">30 minutes. No commitment. We'll discuss your goals and whether RoarAdd is a good fit.</p>
                  <Button variant="gradient" className="w-full gap-2 group" asChild>
                    <Link href="/services/it-consulting">Schedule a Call <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></Link>
                  </Button>
                </div>

                {/* Product quick links */}
                <div className="glass-panel rounded-2xl p-6 border border-white/10">
                  <h3 className="font-bold text-white mb-4">Explore our products</h3>
                  <div className="space-y-2">
                    {[
                      { icon: LayoutDashboard, color: "text-primary", href: "/trackit", name: "Trackit", desc: "Smart analytics & tracking" },
                      { icon: Leaf, color: "text-green-400", href: "/farm", name: "Farm", desc: "Modern farm management" },
                      { icon: Building2, color: "text-blue-400", href: "/services/it-consulting", name: "IT Consulting", desc: "Cloud & enterprise strategy" },
                      { icon: Bot, color: "text-purple-400", href: "/services/aip", name: "AIP — AI to AI", desc: "Agent-to-agent gateway" },
                    ].map(item => (
                      <Link key={item.name} href={item.href}>
                        <div className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group">
                          <item.icon className={`w-4 h-4 ${item.color} flex-shrink-0`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-white">{item.name}</p>
                            <p className="text-xs text-muted-foreground">{item.desc}</p>
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-white transition-colors" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
