import { motion } from "framer-motion";
import { Link } from "wouter";
import { 
  ArrowRight, 
  TrendingUp, 
  Droplets, 
  Sun, 
  Zap, 
  Users, 
  CheckCircle2, 
  AlertCircle, 
  DollarSign, 
  BarChart3, 
  Activity,
  Warehouse,
  Leaf,
  ChevronLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const kpis = [
  { label: "Total CAPEX", value: "$409,200", icon: DollarSign, color: "text-emerald-400" },
  { label: "Target Funding", value: "$250,000", icon: TrendingUp, color: "text-blue-400" },
  { label: "Yr 1 Revenue", value: "$232,200", icon: BarChart3, color: "text-purple-400" },
  { label: "Solar Capacity", value: "45 kW", icon: Sun, color: "text-yellow-400" },
  { label: "Water Savings", value: "90%", icon: Droplets, color: "text-cyan-400" },
];

const revenueData = [
  { stream: "Specialty Mushrooms", y1: "$43,200", y2: "$74,880", y3: "$109,200" },
  { stream: "Branded Microgreens", y1: "$144,000", y2: "$216,720", y3: "$303,600" },
  { stream: "Herbs & Greens", y1: "$45,000", y2: "$60,000", y3: "$77,000" },
];

const actionItems = [
  { task: "Register on GA FarmLink", status: "Done", date: "✅ March 21" },
  { task: "VAPG Grant Submission", status: "Urgent", date: "⚠️ April 22" },
  { task: "REAP Solar Grant", status: "In Progress", date: "March 31" },
  { task: "FSA Farm Ownership Loan", status: "Pending", date: "May 1" },
];

const buyers = [
  { name: "Atlanta Restaurant Group", commitment: "20 trays/wk", status: "Pending" },
  { name: "Local Grocery Co-op", commitment: "30 trays/wk", status: "Contacted" },
  { name: "Farmers Market Network", commitment: "20 lbs/wk", status: "Pending" },
];

export default function FarmDashboard() {
  return (
    <div className="relative min-h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      <div className="fixed top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] bg-emerald-500/10 blur-[150px] rounded-full pointer-events-none" />

      <main className="pt-24 pb-16 px-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <Link href="/farm">
            <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-white transition-colors mb-6 group">
              <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Farm Overview
            </button>
          </Link>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">OPERATIONS HUB</Badge>
                <span className="text-xs text-muted-foreground font-mono">UEI: KG9XV8M5P4L3</span>
              </div>
              <h1 className="text-4xl font-extrabold tracking-tight">RoarAdd <span className="text-gradient">Farm Dashboard</span></h1>
              <p className="text-muted-foreground mt-2">Circular Bio-Economy Farm · Loganville, GA</p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="gap-2">
                <Activity className="w-4 h-4" /> Real-time Feed
              </Button>
              <Button variant="gradient" size="sm" className="gap-2">
                <Warehouse className="w-4 h-4" /> Inventory Management
              </Button>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {kpis.map((kpi, i) => (
            <motion.div
              key={kpi.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="glass-panel border-white/5">
                <CardHeader className="p-4 pb-0">
                  <kpi.icon className={`w-5 h-5 ${kpi.color} mb-2`} />
                  <CardTitle className="text-2xl font-bold tracking-tight">{kpi.value}</CardTitle>
                  <CardDescription className="text-xs uppercase tracking-wider">{kpi.label}</CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className={`h-full ${kpi.color.replace('text', 'bg')} w-[70%]`} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Revenue Projections */}
          <Card className="glass-panel lg:col-span-2 border-white/5">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>3-Year Revenue Projections</CardTitle>
                  <CardDescription>Conservative growth scenario by product stream</CardDescription>
                </div>
                <TrendingUp className="w-5 h-5 text-emerald-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/5 text-muted-foreground">
                      <th className="text-left py-3 font-medium uppercase tracking-wider text-[10px]">Product Stream</th>
                      <th className="text-right py-3 font-medium uppercase tracking-wider text-[10px]">Year 1</th>
                      <th className="text-right py-3 font-medium uppercase tracking-wider text-[10px]">Year 2</th>
                      <th className="text-right py-3 font-medium uppercase tracking-wider text-[10px]">Year 3</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {revenueData.map((row) => (
                      <tr key={row.stream} className="hover:bg-white/5 transition-colors group">
                        <td className="py-4 font-medium text-white group-hover:text-emerald-400 transition-colors">{row.stream}</td>
                        <td className="py-4 text-right text-muted-foreground">{row.y1}</td>
                        <td className="py-4 text-right text-muted-foreground">{row.y2}</td>
                        <td className="py-4 text-right text-emerald-400 font-semibold">{row.y3}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t border-white/10">
                      <td className="py-4 font-bold text-white">Gross Total</td>
                      <td className="py-4 text-right font-bold text-muted-foreground">$232,200</td>
                      <td className="py-4 text-right font-bold text-muted-foreground">$351,600</td>
                      <td className="py-4 text-right font-bold text-emerald-400">$489,800</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Action Items */}
          <Card className="glass-panel border-white/5">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Action Items</CardTitle>
                  <CardDescription>Weekly operational milestones</CardDescription>
                </div>
                <CheckCircle2 className="w-5 h-5 text-blue-400" />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {actionItems.map((item) => (
                <div key={item.task} className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 transition-all">
                  <div className={`mt-1 w-2 h-2 rounded-full ${item.status === 'Done' ? 'bg-emerald-500' : item.status === 'Urgent' ? 'bg-red-500 animate-pulse' : 'bg-blue-500'}`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium leading-none mb-1">{item.task}</p>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-widest">{item.date}</p>
                  </div>
                  <Badge variant="outline" className={`text-[10px] ${item.status === 'Done' ? 'border-emerald-500/20 text-emerald-400' : 'border-blue-500/20 text-blue-400'}`}>
                    {item.status}
                  </Badge>
                </div>
              ))}
              <Button variant="ghost" className="w-full text-xs text-muted-foreground hover:text-white mt-2">
                View Full Roadmap <ArrowRight className="w-3 h-3 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mt-8">
          {/* Buyer Pipeline */}
          <Card className="glass-panel border-white/5">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Buyer LOI Pipeline</CardTitle>
                  <CardDescription>Target: 5 signed by April 10</CardDescription>
                </div>
                <Users className="w-5 h-5 text-purple-400" />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {buyers.map((buyer) => (
                <div key={buyer.name} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 group hover:border-purple-500/20 transition-all">
                  <div>
                    <p className="font-semibold text-sm group-hover:text-purple-400 transition-colors">{buyer.name}</p>
                    <p className="text-xs text-muted-foreground">{buyer.commitment}</p>
                  </div>
                  <Badge className={buyer.status === 'Signed' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-purple-500/10 text-purple-400'}>
                    {buyer.status}
                  </Badge>
                </div>
              ))}
              <div className="p-4 rounded-xl border border-dashed border-white/10 text-center cursor-pointer hover:bg-white/5 transition-colors group">
                <p className="text-xs text-muted-foreground group-hover:text-white transition-colors">+ Add New Buyer Target</p>
              </div>
            </CardContent>
          </Card>

          {/* Operational Heartbeat */}
          <Card className="glass-panel border-white/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-3xl pointer-events-none" />
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Operational Heartbeat</CardTitle>
                  <CardDescription>Circular loop efficiency metrics</CardDescription>
                </div>
                <Zap className="w-5 h-5 text-yellow-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                  <div className="flex items-center gap-2 mb-3">
                    <Leaf className="w-4 h-4 text-emerald-400" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">CO₂ Capture</span>
                  </div>
                  <p className="text-3xl font-extrabold text-white">92<span className="text-lg font-normal text-muted-foreground ml-1">%</span></p>
                  <p className="text-[10px] text-emerald-400 mt-1">Target Efficiency Met</p>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                  <div className="flex items-center gap-2 mb-3">
                    <Sun className="w-4 h-4 text-yellow-400" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Energy Balance</span>
                  </div>
                  <p className="text-3xl font-extrabold text-white">85<span className="text-lg font-normal text-muted-foreground ml-1">%</span></p>
                  <p className="text-[10px] text-yellow-400 mt-1">Self-Sufficiency Target</p>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                  <div className="flex items-center gap-2 mb-3">
                    <Droplets className="w-4 h-4 text-blue-400" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Water Loop</span>
                  </div>
                  <p className="text-3xl font-extrabold text-white">2.1<span className="text-lg font-normal text-muted-foreground ml-1">L/m</span></p>
                  <p className="text-[10px] text-blue-400 mt-1">Recirculation Optimal</p>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                  <div className="flex items-center gap-2 mb-3">
                    <AlertCircle className="w-4 h-4 text-purple-400" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Yield Boost</span>
                  </div>
                  <p className="text-3xl font-extrabold text-white">+20<span className="text-lg font-normal text-muted-foreground ml-1">%</span></p>
                  <p className="text-[10px] text-purple-400 mt-1">Photosynthesis Alpha</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
