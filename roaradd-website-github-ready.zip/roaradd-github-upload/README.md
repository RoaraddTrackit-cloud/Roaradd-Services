# RoarAdd Website

Official website for [RoarAdd LLC](https://roaradd.com) — products and services for the next generation of business.

## Stack

- **React 19** + **TypeScript**
- **Vite 6** (build tool)
- **Tailwind CSS v4**
- **Framer Motion** (animations)
- **Wouter** (routing)
- **shadcn/ui** components

## Pages

| Route | Page |
|---|---|
| `/` | Home |
| `/trackit` | Trackit — SaaS Analytics |
| `/farm` | Farm — Agricultural Management |
| `/services/it-consulting` | IT Consulting |
| `/services/aip` | AIP — AI to AI Gateway |
| `/about` | About Us |
| `/contact` | Contact |

## Local Development

```bash
cd website
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## Build

```bash
cd website
npm run build
```

Output goes to `website/dist/`.

## Deployment

This repo auto-deploys to **GitHub Pages** on every push to `main` via the GitHub Actions workflow in `.github/workflows/deploy.yml`.

To deploy manually:
1. Go to **Actions** tab in GitHub
2. Select **Deploy to GitHub Pages**
3. Click **Run workflow**

## Contact

- **Email:** kalyan.modium@roaradd.com
- **Website:** [roaradd.com](https://roaradd.com)

© 2025 RoarAdd LLC. All rights reserved.
